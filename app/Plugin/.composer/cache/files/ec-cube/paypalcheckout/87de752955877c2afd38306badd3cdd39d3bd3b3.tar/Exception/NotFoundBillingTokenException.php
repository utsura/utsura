<?php

namespace Plugin\PayPalCheckout\Exception;

/**
 * Class NotFoundBillingTokenException
 * @package Plugin\PayPalCheckout\Exception
 */
class NotFoundBillingTokenException extends PayPalCheckoutException
{
}
