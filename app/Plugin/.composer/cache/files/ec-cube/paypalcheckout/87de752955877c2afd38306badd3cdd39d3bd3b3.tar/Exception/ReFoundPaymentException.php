<?php

namespace Plugin\PayPalCheckout\Exception;

/**
 * Class ReFoundPaymentException
 * @package Plugin\PayPalCheckout\Exception
 */
class ReFoundPaymentException extends PayPalCheckoutException
{
}
