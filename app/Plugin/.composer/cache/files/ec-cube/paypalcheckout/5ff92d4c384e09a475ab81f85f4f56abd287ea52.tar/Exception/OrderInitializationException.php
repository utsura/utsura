<?php

namespace Plugin\PayPalCheckout\Exception;

/**
 * Class OrderInitializationException
 * @package Plugin\PayPalCheckout\Exception
 */
class OrderInitializationException extends PayPalCheckoutException
{
}
