<?php

namespace Plugin\PayPalCheckout\Exception;

class NotFoundSnippetException extends PayPalCheckoutException
{
}
