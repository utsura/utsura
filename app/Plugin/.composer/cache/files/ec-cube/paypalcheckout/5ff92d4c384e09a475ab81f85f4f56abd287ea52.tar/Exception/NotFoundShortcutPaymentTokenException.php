<?php

namespace Plugin\PayPalCheckout\Exception;

/**
 * Class NotFoundShortcutPaymentTokenException
 * @package Plugin\PayPalCheckout\Exception
 */
class NotFoundShortcutPaymentTokenException extends PayPalCheckoutException
{
}
