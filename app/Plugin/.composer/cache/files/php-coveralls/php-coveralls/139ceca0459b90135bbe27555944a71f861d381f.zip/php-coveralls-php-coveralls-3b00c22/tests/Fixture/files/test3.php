<?php
namespace Hoge;

class TestFileBis
{
    public function __construct()
    {
        $this->message = 'hoge';
    }
}
