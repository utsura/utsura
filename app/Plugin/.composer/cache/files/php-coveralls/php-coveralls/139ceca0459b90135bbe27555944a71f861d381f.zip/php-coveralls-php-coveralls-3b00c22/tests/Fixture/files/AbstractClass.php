<?php

abstract class AbstractClass
{
    abstract public function hello();
}
