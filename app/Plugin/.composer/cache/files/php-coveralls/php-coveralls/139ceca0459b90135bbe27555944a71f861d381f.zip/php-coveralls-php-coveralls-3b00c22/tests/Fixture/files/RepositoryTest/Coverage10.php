<?php
namespace CoverallsTest;

class Coverage10
{
    public function doSomething()
    {
        $var = '';
    }
}
