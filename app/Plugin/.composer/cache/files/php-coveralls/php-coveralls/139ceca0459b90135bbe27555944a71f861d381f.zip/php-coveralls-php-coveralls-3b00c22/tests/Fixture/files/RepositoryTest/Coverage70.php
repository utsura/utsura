<?php
namespace CoverallsTest;

class Coverage70
{
    public function doSomething()
    {
        $var = '';
    }
}
