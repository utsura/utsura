<?php
namespace CoverallsTest;

class Coverage0
{
    public function doSomething()
    {
        $var = '';
    }
}
