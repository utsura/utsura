<?php

interface TestInterface
{
    public function hello();
}
