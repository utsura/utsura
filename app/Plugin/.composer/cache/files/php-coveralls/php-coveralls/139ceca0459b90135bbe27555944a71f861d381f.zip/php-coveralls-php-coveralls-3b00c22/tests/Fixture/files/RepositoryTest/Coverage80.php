<?php
namespace CoverallsTest;

class Coverage80
{
    public function doSomething()
    {
        $var = '';
    }
}
