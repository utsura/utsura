<?php

namespace Facebook\WebDriver\Exception;

class NoCollectionException extends WebDriverException
{
}
